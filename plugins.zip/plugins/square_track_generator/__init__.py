from .action import SquareTrackAction
SquareTrackAction().register()
