from .action import ViaFenceAction
ViaFenceAction().register()
